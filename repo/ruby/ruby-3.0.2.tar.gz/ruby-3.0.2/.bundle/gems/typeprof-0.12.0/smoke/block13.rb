foo do |n|
  p n
end

__END__
# Revealed types
#  smoke/block13.rb:2 #=> Integer?

# Classes
