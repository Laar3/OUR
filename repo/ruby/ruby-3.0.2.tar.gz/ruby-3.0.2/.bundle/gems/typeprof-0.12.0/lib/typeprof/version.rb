module TypeProf
  VERSION = "0.12.0"
end
