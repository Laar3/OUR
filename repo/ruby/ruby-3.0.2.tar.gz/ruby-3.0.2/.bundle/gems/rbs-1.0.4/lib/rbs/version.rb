module RBS
  VERSION = "1.0.4"
end
